var classOnlineMapsVector2i =
[
    [ "OnlineMapsVector2i", "classOnlineMapsVector2i.html#a7d3bfa0e479758da2d7d502e209be7bf", null ],
    [ "ToString", "classOnlineMapsVector2i.html#acb77b2dc7d081d8db5f7a5219e779870", null ],
    [ "x", "classOnlineMapsVector2i.html#a5fe643df0a0a48fba375d03550b08bd4", null ],
    [ "y", "classOnlineMapsVector2i.html#afd1c80bddde2c0f38858747221071fab", null ]
];