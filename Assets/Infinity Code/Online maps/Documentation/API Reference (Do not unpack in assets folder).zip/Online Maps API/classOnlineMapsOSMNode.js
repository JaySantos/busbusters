var classOnlineMapsOSMNode =
[
    [ "OnlineMapsOSMNode", "classOnlineMapsOSMNode.html#a75fb9e2f46889b3796180537834b176f", null ],
    [ "lat", "classOnlineMapsOSMNode.html#ac8c18509e173a367f78854ae6a241422", null ],
    [ "lon", "classOnlineMapsOSMNode.html#a78c3af702b3998d3cd927d5a2861a14f", null ]
];