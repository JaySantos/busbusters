var classOnlineMapsFindDirection =
[
    [ "OnlineMapsFindDirection", "classOnlineMapsFindDirection.html#abb26657fa4440e9b2bc5e0f878235cc4", null ],
    [ "type", "classOnlineMapsFindDirection.html#a9f11ae7304981d7e74e301fa7e00b769", null ]
];