var classOnlineMapsOSMRelationMember =
[
    [ "OnlineMapsOSMRelationMember", "classOnlineMapsOSMRelationMember.html#a31ddd07397e0d11a922c3da66981caa5", null ],
    [ "reference", "classOnlineMapsOSMRelationMember.html#adcdab169db7377bb505c4545e980c030", null ],
    [ "role", "classOnlineMapsOSMRelationMember.html#abbf9dc4e2fbafcb4d5290ce3a6f4d040", null ],
    [ "type", "classOnlineMapsOSMRelationMember.html#ad31e7b8d52b35edb749698801e8a62c6", null ]
];