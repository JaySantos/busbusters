var classOnlineMapsSpriteRendererControl =
[
    [ "GetCoords", "classOnlineMapsSpriteRendererControl.html#a031e3a2d163b26f62683ea8fa980869b", null ],
    [ "OnEnableLate", "classOnlineMapsSpriteRendererControl.html#a75062b13a3ebdedeae998b16582f8905", null ],
    [ "SetTexture", "classOnlineMapsSpriteRendererControl.html#ae429b931053ab8e113be99b784cf3b4c", null ]
];