var hierarchy =
[
    [ "MonoBehaviour", null, [
      [ "OnlineMaps", "classOnlineMaps.html", null ],
      [ "OnlineMapsControlBase", "classOnlineMapsControlBase.html", [
        [ "OnlineMapsControlBase2D", "classOnlineMapsControlBase2D.html", [
          [ "OnlineMapsDFGUITextureControl", "classOnlineMapsDFGUITextureControl.html", null ],
          [ "OnlineMapsGUITextureControl", "classOnlineMapsGUITextureControl.html", null ],
          [ "OnlineMapsIGUITextureControl", "classOnlineMapsIGUITextureControl.html", null ],
          [ "OnlineMapsNGUITextureControl", "classOnlineMapsNGUITextureControl.html", null ],
          [ "OnlineMapsSpriteRendererControl", "classOnlineMapsSpriteRendererControl.html", null ],
          [ "OnlineMapsUIImageControl", "classOnlineMapsUIImageControl.html", null ],
          [ "OnlineMapsUIRawImageControl", "classOnlineMapsUIRawImageControl.html", null ]
        ] ],
        [ "OnlineMapsControlBase3D", "classOnlineMapsControlBase3D.html", [
          [ "OnlineMapsTextureControl", "classOnlineMapsTextureControl.html", null ],
          [ "OnlineMapsTileSetControl", "classOnlineMapsTileSetControl.html", null ]
        ] ]
      ] ],
      [ "OnlineMapsLocationService", "classOnlineMapsLocationService.html", null ],
      [ "OnlineMapsMarkerInstanceBase", "classOnlineMapsMarkerInstanceBase.html", [
        [ "OnlineMapsMarker3DInstance", "classOnlineMapsMarker3DInstance.html", null ],
        [ "OnlineMapsMarkerBillboard", "classOnlineMapsMarkerBillboard.html", null ]
      ] ],
      [ "OnlineMapsRWTConnector", "classOnlineMapsRWTConnector.html", null ]
    ] ],
    [ "OnlineMapsBuffer", "classOnlineMapsBuffer.html", null ],
    [ "OnlineMapsDirectionStep", "classOnlineMapsDirectionStep.html", null ],
    [ "OnlineMapsDrawingElement", "classOnlineMapsDrawingElement.html", [
      [ "OnlineMapsDrawingLine", "classOnlineMapsDrawingLine.html", null ],
      [ "OnlineMapsDrawingPoly", "classOnlineMapsDrawingPoly.html", null ],
      [ "OnlineMapsDrawingRect", "classOnlineMapsDrawingRect.html", null ]
    ] ],
    [ "OnlineMapsGoogleAPIQuery", "classOnlineMapsGoogleAPIQuery.html", [
      [ "OnlineMapsFindDirection", "classOnlineMapsFindDirection.html", null ],
      [ "OnlineMapsFindLocation", "classOnlineMapsFindLocation.html", null ],
      [ "OnlineMapsOSMAPIQuery", "classOnlineMapsOSMAPIQuery.html", null ]
    ] ],
    [ "OnlineMapsMarkerBase", "classOnlineMapsMarkerBase.html", [
      [ "OnlineMapsMarker", "classOnlineMapsMarker.html", null ],
      [ "OnlineMapsMarker3D", "classOnlineMapsMarker3D.html", null ]
    ] ],
    [ "OnlineMapsOSMBase", "classOnlineMapsOSMBase.html", [
      [ "OnlineMapsOSMNode", "classOnlineMapsOSMNode.html", null ],
      [ "OnlineMapsOSMRelation", "classOnlineMapsOSMRelation.html", null ],
      [ "OnlineMapsOSMWay", "classOnlineMapsOSMWay.html", null ]
    ] ],
    [ "OnlineMapsOSMRelationMember", "classOnlineMapsOSMRelationMember.html", null ],
    [ "OnlineMapsOSMTag", "classOnlineMapsOSMTag.html", null ],
    [ "OnlineMapsPositionRange", "classOnlineMapsPositionRange.html", null ],
    [ "OnlineMapsRange", "classOnlineMapsRange.html", null ],
    [ "OnlineMapsTile", "classOnlineMapsTile.html", null ],
    [ "OnlineMapsVector2i", "classOnlineMapsVector2i.html", null ]
];