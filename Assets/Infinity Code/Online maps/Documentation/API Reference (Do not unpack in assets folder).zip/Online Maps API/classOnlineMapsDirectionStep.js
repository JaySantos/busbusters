var classOnlineMapsDirectionStep =
[
    [ "OnlineMapsDirectionStep", "classOnlineMapsDirectionStep.html#adc6af605524a34ff2eeb2c59e0539219", null ],
    [ "distance", "classOnlineMapsDirectionStep.html#a53d21502f79e1fdf32024928188cd131", null ],
    [ "duration", "classOnlineMapsDirectionStep.html#aa48be2298ada79e19c2ddaa4bf32a88a", null ],
    [ "end", "classOnlineMapsDirectionStep.html#a9eea5e1348a464b0e634462d87267936", null ],
    [ "instructions", "classOnlineMapsDirectionStep.html#ad4b545b21cbef453ee5c99e1dcb23435", null ],
    [ "maneuver", "classOnlineMapsDirectionStep.html#a58f9024719bf6bf36ea135534b1ccd47", null ],
    [ "points", "classOnlineMapsDirectionStep.html#af0fe4dd28ee216b5befe1a1649f61f87", null ],
    [ "start", "classOnlineMapsDirectionStep.html#af0d840fb505d72e4e5cf1f5f209aac2d", null ]
];